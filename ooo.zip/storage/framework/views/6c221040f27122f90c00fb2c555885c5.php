<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo e($product->name); ?></title>
    <style>
        body {
            font-family: Arial, sans-serif;
        }
        .product {
            margin: 20px;
            padding: 20px;
            border: 1px solid #ccc;
            border-radius: 5px;
        }
        .product img {
            max-width: 100%;
            height: auto;
        }
        .price {
            color: green;
            font-size: 24px;
        }
    </style>
</head>
<body>
    <div class="product">
        <h1 id="productTitle"><?php echo e($product->name); ?></h1>
        <img id="productImage" src="<?php echo e($product->image_url); ?>" alt="Product Image">
        <p id="productDescription"><?php echo e($product->description); ?></p>
        <p class="price" id="productPrice">$<?php echo e($product->price); ?></p>
    </div>
</body>
</html><?php /**PATH D:\laravel projects\online store\OnlineStore\resources\views/product/show.blade.php ENDPATH**/ ?>